package main

import "fmt"

func main(){
	var (
		a=8
		b=4
		D = float32(a+b)/2
	)
	fmt.Println("O'rtacha qiymat D=:",D)
}