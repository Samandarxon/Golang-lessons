package main

import (
	"fmt"
	"math"
)

func main(){
	var (
		a=8
		b=4
		D =math.Sqrt(float64(a+b))
	)
	fmt.Println("O'rtacha qiymat D=:",D)
}