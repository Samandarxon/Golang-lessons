package main
import "fmt"

func main(){
	var (
		a int = 5
		S int

	)

	S= a*a
	fmt.Println(S)
	
}