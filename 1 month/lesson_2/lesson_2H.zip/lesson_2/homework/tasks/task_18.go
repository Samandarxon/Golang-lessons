package main
import (
	"fmt"
)

func main(){
	var (
		acb = 14
		ac = 6
		bc= acb-ac
	)

	fmt.Println("AC * BC =:",ac*bc)
}