package main

import "fmt"

func main(){
	var (
		a int =3
		V int
		S int

	)

	V = a*a*a
	S= 6*a
	fmt.Printf("Kubning hajmi V=:%d\nKubning  to'la sirti yuzi S=:%d\n",V,S)
}