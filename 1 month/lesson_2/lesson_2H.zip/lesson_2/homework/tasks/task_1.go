package main

import "fmt"

func main() {
	var (
		a int = 3
		P int
	)
	P = 4*a
	fmt.Println(P)
}
