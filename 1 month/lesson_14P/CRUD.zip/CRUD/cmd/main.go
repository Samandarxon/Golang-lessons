package main

import (
	"fmt"

	"app/controller"
	"app/models"

	"github.com/google/uuid"
)

func main() {

	var Products []models.Product

	productConnection := controller.NewProductController(Products)

	_ = productConnection.CreateProduct(models.ProductCreate{
		Id:       uuid.New(),
		Name:     "Apple",
		Price:    10000,
		Quantity: 10,
	})
	_ = productConnection.CreateProduct(models.ProductCreate{
		Id:       uuid.New(),
		Name:     "Acer",
		Price:    3000,
		Quantity: 12,
	})

	products := productConnection.ProductGetList(models.ProductGetListRequest{})

	productg := productConnection.ProdcutGetById(models.ProductPrimaryKey{
		Id: products.Products[0].Id,
	})

	update := productConnection.ProductUpdate(models.ProductUpdate{
		Id:       productg.Id,
		Price:    2000,
		Quantity: 30,
	})
	deleted := productConnection.ProductDelete(models.ProductPrimaryKey{
		Id: productg.Id,
	})
	fmt.Println("All", products)
	fmt.Println()
	fmt.Println("GetByID", productg)
	fmt.Println()
	fmt.Println("update", update)
	fmt.Println()
	fmt.Println("All", products)
	fmt.Println()
	fmt.Println(deleted)
	fmt.Println()
	fmt.Println("All", products)
}
