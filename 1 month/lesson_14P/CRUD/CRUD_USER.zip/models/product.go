package models

import "github.com/google/uuid"

type Product struct {
	Id        uuid.UUID
	Name      string
	Price     int
	Quantity  int
	CreatedAt string
	UpdatedAt string
}

type ProductPrimaryKey struct {
	Id uuid.UUID
}

type ProductCreate struct {
	Id       uuid.UUID
	Name     string
	Price    int
	Quantity int
}

type ProductUpdate struct {
	Id       uuid.UUID
	Price    int
	Quantity int
}

type ProductGetListRequest struct {
	Offset int
	Limit  int
}

type ProductGetListResponse struct {
	Count    int
	Products []Product
}
