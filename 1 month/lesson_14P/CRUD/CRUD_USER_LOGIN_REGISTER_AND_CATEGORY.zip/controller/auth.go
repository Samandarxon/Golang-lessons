package controller

import (
	"app/models"
)

type Auth struct {
	Users []models.User
}
