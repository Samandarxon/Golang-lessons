package handler

import (
	"database/sql"
	"fmt"
	"net/http"

	"github.com/asadbekGo/market_system/models"
	"github.com/gin-gonic/gin"
)

func (h *Handler) CreateProduct(c *gin.Context) {

	var createProduct models.CreateProduct

	err := c.ShouldBindJSON(&createProduct)
	if err != nil {
		c.JSON(http.StatusBadRequest, "ShouldBindJSON err:"+err.Error())
		return
	}

	resp, err := h.strg.Product().Create(&createProduct)
	fmt.Println(resp)
	if err != nil {
		handleResponse(c, http.StatusInternalServerError, err)
		return
	}

	handleResponse(c, http.StatusCreated, resp)
}

func (h *Handler) GetByIDProduct(c *gin.Context) {
	fmt.Println("SAlom men ishladim,,,")
	id := c.Param("id")

	// if !helpers.IsValidUUID(id) {
	// 	handleResponse(w, http.StatusBadRequest, "ID in not uuid")
	// 	return
	// }
	fmt.Println("**************************************", id)
	resp, err := h.strg.Product().GetByID(&models.ProductPrimaryKey{Id: id})

	if err == sql.ErrNoRows {
		handleResponse(c, http.StatusBadRequest, "No rows in result set")
		return
	}

	if err != nil {
		handleResponse(c, http.StatusBadRequest, err)
		return
	}

	handleResponse(c, http.StatusOK, resp)

}

func (h *Handler) GetListProduct(c *gin.Context) {

	limit, err := getIntegerOrDefaultValue(c.Query("limit"), 10)
	if err != nil {
		handleResponse(c, http.StatusBadRequest, "invalid query limit")
		return
	}

	offset, err := getIntegerOrDefaultValue(c.Query("offset"), 0)
	if err != nil {
		handleResponse(c, http.StatusBadRequest, "invalid query offset")
		return
	}

	// title := c.Query("title")
	// categoryId := c.Query("category_id")
	search := c.Query("search")

	if err != nil {
		handleResponse(c, http.StatusBadRequest, "invalid query search")
		return
	}

	resp, err := h.strg.Product().GetList(&models.GetListProductRequest{
		Limit:  limit,
		Offset: offset,
		// Title:      title,
		// CategoryId: categoryId,
		Search: search,
	})

	if err != nil {
		handleResponse(c, http.StatusInternalServerError, err)
		return
	}

	handleResponse(c, http.StatusOK, resp)
}

func (h *Handler) UpdateProduct(c *gin.Context) {
	var updateProduct models.UpdateProduct

	err := c.ShouldBindJSON(&updateProduct)
	if err != nil {
		handleResponse(c, http.StatusBadRequest, err)
		return
	}

	fmt.Printf("UPDATE>>>>>> %+v\n", updateProduct)

	rowsAffected, err := h.strg.Product().Update(&updateProduct)
	if err != nil {
		handleResponse(c, http.StatusInternalServerError, err)
		return
	}

	if rowsAffected == 0 {
		handleResponse(c, http.StatusBadRequest, "no rows affected")
		return
	}

	resp, err := h.strg.Product().GetByID(&models.ProductPrimaryKey{Id: updateProduct.Id})

	if err != nil {
		handleResponse(c, http.StatusInternalServerError, err)
		return
	}

	handleResponse(c, http.StatusOK, resp)
}

func (h *Handler) DeleteProduct(c *gin.Context) {
	var id = c.Param("id")

	fmt.Println(id)
	err := h.strg.Product().Delete(&models.ProductPrimaryKey{Id: id})

	if err != nil {
		handleResponse(c, http.StatusBadRequest, err)
		return
	}
	handleResponse(c, http.StatusOK, "Data was deleted")
}
