drop table airport,city ,country,temp;
