CREATE TABLE country(
    id UUID,
    guid UUID,
    title VARCHAR(64),
    code VARCHAR(12),
    continent VARCHAR(12),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);






  "guid": "d97e8ce7-39cd-4bd8-bf84-530e3e9ba1d9",
  "title": "Andorra",
  "code": "AD",
  "continent": "EU",